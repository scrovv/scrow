
from ollama import Ollama

# Load and fine-tune Ollama model
model = Ollama.load("path-to-ollama-model")

# Fine-tuning the model
data = [{"input": "What is AI?", "output": "Artificial Intelligence is..."}]
model.fine_tune(data=data)

# Generate response after fine-tuning
input_text = "What is the capital of Spain?"
response = model.generate(input_text)
print(response)
