
from taipy import Gui

page = '''
<|input|type=text|label="Query AI"|on_submit=generate_response|>
<|output|>
'''

def generate_response(query):
    return "AI Response: " + query

# Run Taipy app
gui = Gui(page)
gui.run()
