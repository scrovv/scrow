
import chromadb
from supabase import create_client

# Initialize ChromaDB
client = chromadb.Client()
collection = client.create_collection("document_embeddings")

# Initialize Supabase client
supabase_url = "your-supabase-url"
supabase_key = "your-supabase-key"
sb = create_client(supabase_url, supabase_key)

# Example: Store embeddings and retrieve metadata
documents = [{"content": "This is a document."}]
for doc in documents:
    embedding = embeddings.create_embedding(doc['content'])
    collection.add(documents=[doc['content']], embeddings=[embedding])

    # Fetch metadata from Supabase
    response = sb.table('documents').select('*').eq('content', doc['content']).execute()
    metadata = response.data
    print(metadata)
